<?php
$title = 'Dashboard Mahasiswa';
require_once 'includes/header.php';

$id = $_SESSION['mhs_id'];

$hadir = $conn->query("SELECT COUNT(*) c FROM presensi WHERE mahasiswa_id=$id AND status='Hadir'")->fetch_assoc()['c'];
$izin  = $conn->query("SELECT COUNT(*) c FROM presensi WHERE mahasiswa_id=$id AND status='Izin'")->fetch_assoc()['c'];
$sakit = $conn->query("SELECT COUNT(*) c FROM presensi WHERE mahasiswa_id=$id AND status='Sakit'")->fetch_assoc()['c'];
$alpha = $conn->query("SELECT COUNT(*) c FROM presensi WHERE mahasiswa_id=$id AND status='Alpha'")->fetch_assoc()['c'];

$hariIni = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'][date('w')];
$kelas = $_SESSION['mhs_kelas'];
$jadwal = $conn->query("SELECT * FROM jadwal WHERE hari='$hariIni' AND kelas='$kelas' ORDER BY jam_mulai");

include 'includes/navbar.php';
?>
<div class="container py-4">
  <h4 class="mb-4">Halo, <?= $_SESSION['mhs_nama'] ?> 👋</h4>

  <div class="row g-3 mb-4">
    <div class="col-md-3 col-6">
      <div class="card card-stat bg-green p-3">
        <i class="bi bi-check-circle icon"></i>
        <div>Hadir</div><h3><?= $hadir ?></h3>
      </div>
    </div>
    <div class="col-md-3 col-6">
      <div class="card card-stat bg-orange p-3">
        <i class="bi bi-envelope-paper icon"></i>
        <div>Izin</div><h3><?= $izin ?></h3>
      </div>
    </div>
    <div class="col-md-3 col-6">
      <div class="card card-stat bg-purple p-3">
        <i class="bi bi-thermometer-half icon"></i>
        <div>Sakit</div><h3><?= $sakit ?></h3>
      </div>
    </div>
    <div class="col-md-3 col-6">
      <div class="card card-stat bg-red p-3">
        <i class="bi bi-x-circle icon"></i>
        <div>Alpha</div><h3><?= $alpha ?></h3>
      </div>
    </div>
  </div>

  <div class="card p-4">
    <h5><i class="bi bi-calendar-day"></i> Jadwal Hari Ini (<?= $hariIni ?>)</h5>
    <table class="table table-hover mt-3">
      <thead><tr><th>Matkul</th><th>Jam</th><th>Kelas</th></tr></thead>
      <tbody>
        <?php if($jadwal->num_rows): while($j=$jadwal->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($j['mata_kuliah']) ?></td>
            <td><?= substr($j['jam_mulai'],0,5) ?> - <?= substr($j['jam_selesai'],0,5) ?></td>
            <td><?= $j['kelas'] ?></td>
          </tr>
        <?php endwhile; else: ?>
          <tr><td colspan="3" class="text-center text-muted">Tidak ada jadwal hari ini</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
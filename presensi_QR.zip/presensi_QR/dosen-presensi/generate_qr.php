<?php
$title = 'Generate QR';
require_once 'includes/header.php';

$pesan = '';
$qr_result = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['jadwal_id'])) {
    $jadwal_id = (int)$_POST['jadwal_id'];
    $token = bin2hex(random_bytes(16));
    $tanggal = date('Y-m-d');
    $buka = date('Y-m-d H:i:s');
    $tutup = date('Y-m-d H:i:s', strtotime('+15 minutes'));

    // Expire sesi lama
    $conn->query("UPDATE qr_session SET status='expired' WHERE status='aktif'");

    $stmt = $conn->prepare("INSERT INTO qr_session (jadwal_id,token,tanggal,waktu_buka,waktu_tutup) VALUES (?,?,?,?,?)");
    $stmt->bind_param('issss', $jadwal_id, $token, $tanggal, $buka, $tutup);
    $stmt->execute();

    // Data QR mengarah ke URL mahasiswa (ganti domain mahasiswa Anda)
    $urlMhs = "https://mhs-presensi.rf.gd/scan_qr.php?token=" . urlencode($token);
    $qr_result = ['token'=>$token, 'url'=>$urlMhs, 'tutup'=>date('H:i', strtotime($tutup))];
}

$jadwal = $conn->query("SELECT * FROM jadwal ORDER BY hari, jam_mulai");
$sesiAktif = $conn->query("SELECT q.*, j.mata_kuliah, j.kelas FROM qr_session q JOIN jadwal j ON q.jadwal_id=j.id WHERE q.status='aktif' ORDER BY q.id DESC LIMIT 1")->fetch_assoc();

include 'includes/navbar.php';
?>
<div class="container-fluid py-4 px-4">
  <h4 class="mb-4"><i class="bi bi-qr-code"></i> Generate QR Code</h4>

  <div class="row g-4">
    <div class="col-md-5">
      <div class="card p-3">
        <h5>Pilih Jadwal</h5>
        <form method="post">
          <select name="jadwal_id" class="form-select mb-3" required>
            <option value="">-- Pilih Jadwal --</option>
            <?php while($j = $jadwal->fetch_assoc()): ?>
              <option value="<?= $j['id'] ?>">
                <?= $j['hari'] ?> | <?= htmlspecialchars($j['mata_kuliah']) ?> (<?= $j['kelas'] ?>)
                - <?= substr($j['jam_mulai'],0,5) ?>
              </option>
            <?php endwhile; ?>
          </select>
          <button class="btn btn-primary w-100"><i class="bi bi-qr-code"></i> Generate QR</button>
        </form>

        <?php if ($sesiAktif): ?>
          <div class="alert alert-info mt-3 mb-0">
            <strong>Sesi Aktif:</strong> <?= htmlspecialchars($sesiAktif['mata_kuliah']) ?><br>
            <small>Expired: <?= $sesiAktif['waktu_tutup'] ?></small>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <div class="col-md-7">
      <?php if ($qr_result): ?>
        <div class="card p-4 text-center">
          <h5>QR Code Sesi Presensi</h5>
          <img src="https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=<?= urlencode($qr_result['url']) ?>" 
               alt="QR Code" class="mx-auto my-3 rounded border p-2 bg-white">
          <p class="mb-1"><strong>Berlaku sampai:</strong> <?= $qr_result['tutup'] ?> (15 menit)</p>
          <p class="text-muted small">Token: <?= $qr_result['token'] ?></p>
          <div class="d-flex justify-content-center gap-2">
            <button class="btn btn-outline-secondary" onclick="window.print()"><i class="bi bi-printer"></i> Print</button>
            <a class="btn btn-outline-primary" href="<?= $qr_result['url'] ?>" target="_blank"><i class="bi bi-box-arrow-up-right"></i> Buka Link</a>
          </div>
        </div>
      <?php else: ?>
        <div class="card p-5 text-center text-muted">
          <i class="bi bi-qr-code" style="font-size:5rem; opacity:.3"></i>
          <p class="mt-2">QR Code akan muncul di sini setelah Anda memilih jadwal</p>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
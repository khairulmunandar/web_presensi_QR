<?php
require_once 'config/database.php';
cekLogin();
require 'vendor/autoload.php';

use PhpOffice\PhpWord\PhpWord;
use PhpOffice\PhpWord\Style\Font;

$dari = $_GET['dari'] ?? date('Y-m-01');
$sampai = $_GET['sampai'] ?? date('Y-m-d');
$matkul = $_GET['matkul'] ?? '';
$kelas = $_GET['kelas'] ?? '';

$where = "WHERE p.tanggal BETWEEN '$dari' AND '$sampai'";
if ($matkul) $where .= " AND j.mata_kuliah='".$conn->real_escape_string($matkul)."'";
if ($kelas)  $where .= " AND j.kelas='".$conn->real_escape_string($kelas)."'";

$sql = "SELECT p.*, m.nim, m.nama, j.mata_kuliah, j.kelas 
        FROM presensi p 
        JOIN mahasiswa m ON p.mahasiswa_id=m.id 
        JOIN jadwal j ON p.jadwal_id=j.id 
        $where ORDER BY p.tanggal, p.jam_presensi";
$data = $conn->query($sql);
$dosen = $conn->query("SELECT nama FROM dosen LIMIT 1")->fetch_assoc();

$phpWord = new PhpWord();
$section = $phpWord->addSection();

$section->addText('UNIVERSITAS NAMA KAMPUS', ['bold'=>true,'size'=>16], ['alignment'=>'center']);
$section->addText('LAPORAN PRESENSI MAHASISWA', ['bold'=>true,'size'=>14], ['alignment'=>'center']);
$section->addText('Periode: '.$dari.' s/d '.$sampai, ['size'=>11], ['alignment'=>'center']);
$section->addTextBreak(1);

$table = $section->addTable(['borderSize'=>6,'borderColor'=>'333333','cellMargin'=>80]);
$table->addRow();
foreach(['No','NIM','Nama','Mata Kuliah','Kelas','Tanggal','Jam','Status'] as $h) {
    $table->addCell(1500, ['bgColor'=>'DBEAFE'])->addText($h, ['bold'=>true]);
}

$no = 1;
while($r = $data->fetch_assoc()) {
    $table->addRow();
    $table->addCell(500)->addText($no++);
    $table->addCell(1200)->addText($r['nim']);
    $table->addCell(1800)->addText($r['nama']);
    $table->addCell(2000)->addText($r['mata_kuliah']);
    $table->addCell(800)->addText($r['kelas']);
    $table->addCell(1200)->addText($r['tanggal']);
    $table->addCell(800)->addText(substr($r['jam_presensi'],0,5));
    $table->addCell(900)->addText($r['status']);
}

$section->addTextBreak(2);
$section->addText('Dicetak: '.date('d-m-Y H:i'), [], ['alignment'=>'right']);
$section->addText('Dosen Pengampu,', [], ['alignment'=>'right']);
$section->addTextBreak(3);
$section->addText($dosen['nama'], ['bold'=>true], ['alignment'=>'right']);

$filename = 'Laporan_Presensi_'.$dari.'.docx';
header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
header('Content-Disposition: attachment; filename="'.$filename.'"');
$writer = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
$writer->save('php://output');
exit;
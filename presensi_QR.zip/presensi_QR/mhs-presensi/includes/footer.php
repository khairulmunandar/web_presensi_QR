<!-- footer.php -->
<footer class="text-center py-4 text-muted mt-5 border-top">
  <small>&copy; <?= date('Y') ?> Sistem Presensi QR Code</small>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script>
$(function(){ $('.datatable').DataTable({responsive:true,language:{url:'//cdn.datatables.net/plug-ins/1.13.6/i18n/id.json'}}); });
</script>
</body>
</html>
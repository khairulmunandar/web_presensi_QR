<?php
require_once 'config/database.php';
header('Content-Type: application/json');

if (!isset($_SESSION['mhs_id'])) {
    echo json_encode(['success'=>false,'message'=>'Silakan login terlebih dahulu']); exit;
}

$token = $_GET['token'] ?? '';
if (!$token) { echo json_encode(['success'=>false,'message'=>'Token tidak valid']); exit; }

$stmt = $conn->prepare("SELECT q.*, j.mata_kuliah, j.kelas FROM qr_session q 
                        JOIN jadwal j ON q.jadwal_id=j.id 
                        WHERE q.token=? LIMIT 1");
$stmt->bind_param('s', $token);
$stmt->execute();
$sesi = $stmt->get_result()->fetch_assoc();

if (!$sesi) { echo json_encode(['success'=>false,'message'=>'QR Code tidak ditemukan']); exit; }
if ($sesi['status'] !== 'aktif') { echo json_encode(['success'=>false,'message'=>'QR Code sudah tidak aktif']); exit; }
if (strtotime($sesi['waktu_tutup']) < time()) {
    $conn->query("UPDATE qr_session SET status='expired' WHERE id=".$sesi['id']);
    echo json_encode(['success'=>false,'message'=>'QR Code sudah kedaluwarsa (lewat 15 menit)']); exit;
}
$mhs_id = (int)$_SESSION['mhs_id'];
$jadwal_id = $sesi['jadwal_id'];
$tanggal = date('Y-m-d');
$jam = date('H:i:s');

// Cek duplikat
$cek = $conn->query("SELECT id FROM presensi WHERE mahasiswa_id=$mhs_id AND jadwal_id=$jadwal_id AND tanggal='$tanggal'");
if ($cek->num_rows > 0) {
    echo json_encode(['success'=>false,'message'=>'Anda sudah melakukan presensi untuk mata kuliah ini hari ini']); exit;
}

$stmt = $conn->prepare("INSERT INTO presensi (mahasiswa_id, jadwal_id, qr_session_id, tanggal, jam_presensi, status) VALUES (?,?,?,?,?,'Hadir')");
$stmt->bind_param('iiiss', $mhs_id, $jadwal_id, $sesi['id'], $tanggal, $jam);
if ($stmt->execute()) {
    echo json_encode(['success'=>true,'message'=>'Presensi berhasil! Matkul: '.$sesi['mata_kuliah']]);
} else {
    echo json_encode(['success'=>false,'message'=>'Gagal menyimpan presensi']);
}
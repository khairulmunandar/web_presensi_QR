<?php
$title = 'Laporan Presensi';
require_once 'includes/header.php';

$jenis = $_GET['jenis'] ?? 'harian';
$dari = $_GET['dari'] ?? date('Y-m-01');
$sampai = $_GET['sampai'] ?? date('Y-m-d');
$matkul = $_GET['matkul'] ?? '';
$kelas = $_GET['kelas'] ?? '';

$where = "WHERE p.tanggal BETWEEN '$dari' AND '$sampai'";
if ($matkul) $where .= " AND j.mata_kuliah='".$conn->real_escape_string($matkul)."'";
if ($kelas)  $where .= " AND j.kelas='".$conn->real_escape_string($kelas)."'";

$sql = "SELECT p.*, m.nim, m.nama, j.mata_kuliah, j.kelas 
        FROM presensi p 
        JOIN mahasiswa m ON p.mahasiswa_id=m.id 
        JOIN jadwal j ON p.jadwal_id=j.id 
        $where ORDER BY p.tanggal DESC, p.jam_presensi DESC";
$data = $conn->query($sql);

$matkulList = $conn->query("SELECT DISTINCT mata_kuliah FROM jadwal");
$kelasList = $conn->query("SELECT DISTINCT kelas FROM jadwal");

include 'includes/navbar.php';
?>
<div class="container-fluid py-4 px-4">
  <h4 class="mb-4"><i class="bi bi-file-earmark-text"></i> Laporan Presensi</h4>

  <ul class="nav nav-pills mb-3">
    <li class="nav-item"><a class="nav-link <?= $jenis=='harian'?'active':'' ?>" href="?jenis=harian">Harian</a></li>
    <li class="nav-item"><a class="nav-link <?= $jenis=='matkul'?'active':'' ?>" href="?jenis=matkul">Per Mata Kuliah</a></li>
    <li class="nav-item"><a class="nav-link <?= $jenis=='kelas'?'active':'' ?>" href="?jenis=kelas">Per Kelas</a></li>
    <li class="nav-item"><a class="nav-link <?= $jenis=='rekap'?'active':'' ?>" href="?jenis=rekap">Rekap Kehadiran</a></li>
  </ul>

  <div class="card p-3 mb-3">
    <form class="row g-2" method="get">
      <input type="hidden" name="jenis" value="<?= $jenis ?>">
      <div class="col-md-3"><label>Dari</label><input type="date" name="dari" class="form-control" value="<?= $dari ?>"></div>
      <div class="col-md-3"><label>Sampai</label><input type="date" name="sampai" class="form-control" value="<?= $sampai ?>"></div>
      <div class="col-md-2"><label>Matkul</label>
        <select name="matkul" class="form-select">
          <option value="">Semua</option>
          <?php while($m = $matkulList->fetch_assoc()): ?>
            <option <?= $m['mata_kuliah']==$matkul?'selected':'' ?>><?= htmlspecialchars($m['mata_kuliah']) ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="col-md-2"><label>Kelas</label>
        <select name="kelas" class="form-select">
          <option value="">Semua</option>
          <?php while($k = $kelasList->fetch_assoc()): ?>
            <option <?= $k['kelas']==$kelas?'selected':'' ?>><?= $k['kelas'] ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="col-md-2 d-flex align-items-end">
        <button class="btn btn-primary w-100"><i class="bi bi-funnel"></i> Filter</button>
      </div>
    </form>
  </div>

  <div class="card p-3">
    <div class="d-flex justify-content-end gap-2 mb-2">
      <?php $q = http_build_query($_GET); ?>
      <a href="export_pdf.php?<?= $q ?>" target="_blank" class="btn btn-danger btn-sm"><i class="bi bi-file-pdf"></i> PDF</a>
      <a href="export_excel.php?<?= $q ?>" class="btn btn-success btn-sm"><i class="bi bi-file-excel"></i> Excel</a>
      <a href="export_word.php?<?= $q ?>" class="btn btn-primary btn-sm"><i class="bi bi-file-word"></i> Word</a>
    </div>

    <div class="table-responsive">
      <table class="table table-bordered table-hover datatable">
        <thead class="table-light">
          <tr><th>NIM</th><th>Nama</th><th>Matkul</th><th>Kelas</th><th>Tanggal</th><th>Jam</th><th>Status</th></tr>
        </thead>
        <tbody>
          <?php while($r = $data->fetch_assoc()): ?>
            <tr>
              <td><?= $r['nim'] ?></td>
              <td><?= htmlspecialchars($r['nama']) ?></td>
              <td><?= htmlspecialchars($r['mata_kuliah']) ?></td>
              <td><?= $r['kelas'] ?></td>
              <td><?= $r['tanggal'] ?></td>
              <td><?= substr($r['jam_presensi'],0,5) ?></td>
              <td><?= $r['status'] ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
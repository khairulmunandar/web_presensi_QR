<?php
$title = 'Profil Mahasiswa';
require_once 'includes/header.php';

$id = $_SESSION['mhs_id'];
$pesan = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profil'])) {
        $nama = $conn->real_escape_string($_POST['nama']);
        $email = $conn->real_escape_string($_POST['email']);
        if (!empty($_FILES['foto']['name'])) {
            $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
            $foto = 'mhs_' . time() . '.' . $ext;
            move_uploaded_file($_FILES['foto']['tmp_name'], 'assets/images/' . $foto);
            $conn->query("UPDATE mahasiswa SET nama='$nama', email='$email', foto='$foto' WHERE id=$id");
        } else {
            $conn->query("UPDATE mahasiswa SET nama='$nama', email='$email' WHERE id=$id");
        }
        $_SESSION['mhs_nama'] = $nama;
        $pesan = 'Profil diperbarui.';
    }
    if (isset($_POST['ganti_pass'])) {
        $lama = $_POST['lama'];
        $baru = password_hash($_POST['baru'], PASSWORD_DEFAULT);
        $cek = $conn->query("SELECT password FROM mahasiswa WHERE id=$id")->fetch_assoc();
        if (password_verify($lama, $cek['password'])) {
            $conn->query("UPDATE mahasiswa SET password='$baru' WHERE id=$id");
            $pesan = 'Password diubah.';
        } else {
            $pesan = 'Password lama salah!';
        }
    }
}

$m = $conn->query("SELECT * FROM mahasiswa WHERE id=$id")->fetch_assoc();
include 'includes/navbar.php';
?>
<div class="container py-4">
  <h4 class="mb-4"><i class="bi bi-person-circle"></i> Profil Mahasiswa</h4>
  <?php if($pesan): ?><div class="alert alert-info"><?= $pesan ?></div><?php endif; ?>

  <div class="row g-4">
    <div class="col-md-6">
      <div class="card p-4">
        <h5>Data Mahasiswa</h5>
        <form method="post" enctype="multipart/form-data">
          <div class="text-center mb-3">
            <img src="assets/images/<?= $m['foto'] ?>" 
                 onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($m['nama']) ?>&size=120'"
                 class="rounded-circle" width="120" height="120" style="object-fit:cover">
          </div>
          <div class="mb-2"><label>NIM</label><input class="form-control" value="<?= $m['nim'] ?>" readonly></div>
          <div class="mb-2"><label>Kelas</label><input class="form-control" value="<?= $m['kelas'] ?>" readonly></div>
          <div class="mb-2"><label>Nama</label><input name="nama" class="form-control" value="<?= htmlspecialchars($m['nama']) ?>" required></div>
          <div class="mb-2"><label>Email</label><input type="email" name="email" class="form-control" value="<?= htmlspecialchars($m['email']) ?>" required></div>
          <div class="mb-2"><label>Foto</label><input type="file" name="foto" class="form-control" accept="image/*"></div>
          <button name="update_profil" class="btn btn-primary">Simpan</button>
        </form>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card p-4">
        <h5>Ganti Password</h5>
        <form method="post">
          <div class="mb-2"><label>Password Lama</label><input type="password" name="lama" class="form-control" required></div>
          <div class="mb-2"><label>Password Baru</label><input type="password" name="baru" class="form-control" required></div>
          <button name="ganti_pass" class="btn btn-warning">Ganti</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
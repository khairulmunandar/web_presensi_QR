<?php
$title = 'Dashboard';
require_once 'includes/header.php';

$hariIni = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'][date('w')];
$tgl = date('Y-m-d');

$total_mhs = $conn->query("SELECT COUNT(*) c FROM mahasiswa")->fetch_assoc()['c'];
$hadir = $conn->query("SELECT COUNT(*) c FROM presensi WHERE tanggal='$tgl' AND status='Hadir'")->fetch_assoc()['c'];
$izin  = $conn->query("SELECT COUNT(*) c FROM presensi WHERE tanggal='$tgl' AND status='Izin'")->fetch_assoc()['c'];
$sakit = $conn->query("SELECT COUNT(*) c FROM presensi WHERE tanggal='$tgl' AND status='Sakit'")->fetch_assoc()['c'];
$alpha = $conn->query("SELECT COUNT(*) c FROM presensi WHERE tanggal='$tgl' AND status='Alpha'")->fetch_assoc()['c'];

$jadwal = $conn->query("SELECT * FROM jadwal WHERE hari='$hariIni' ORDER BY jam_mulai");

include 'includes/navbar.php';
?>
<div class="container-fluid py-4 px-4">
  <h4 class="mb-4"><i class="bi bi-speedometer2"></i> Dashboard</h4>

  <div class="row g-3 mb-4">
    <div class="col-md-6 col-lg">
      <div class="card card-stat bg-blue p-3">
        <div class="d-flex justify-content-between">
          <div><div>Total Mahasiswa</div><h3><?= $total_mhs ?></h3></div>
          <i class="bi bi-people icon"></i>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg">
      <div class="card card-stat bg-green p-3">
        <div class="d-flex justify-content-between">
          <div><div>Hadir</div><h3><?= $hadir ?></h3></div>
          <i class="bi bi-check-circle icon"></i>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg">
      <div class="card card-stat bg-orange p-3">
        <div class="d-flex justify-content-between">
          <div><div>Izin</div><h3><?= $izin ?></h3></div>
          <i class="bi bi-envelope-paper icon"></i>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg">
      <div class="card card-stat bg-purple p-3">
        <div class="d-flex justify-content-between">
          <div><div>Sakit</div><h3><?= $sakit ?></h3></div>
          <i class="bi bi-thermometer-half icon"></i>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg">
      <div class="card card-stat bg-red p-3">
        <div class="d-flex justify-content-between">
          <div><div>Alpha</div><h3><?= $alpha ?></h3></div>
          <i class="bi bi-x-circle icon"></i>
        </div>
      </div>
    </div>
  </div>

  <div class="card p-4">
    <h5><i class="bi bi-calendar-day"></i> Jadwal Hari Ini (<?= $hariIni ?>)</h5>
    <div class="table-responsive mt-3">
      <table class="table table-hover">
        <thead><tr><th>Mata Kuliah</th><th>Kelas</th><th>Jam</th></tr></thead>
        <tbody>
          <?php if ($jadwal->num_rows): while($j = $jadwal->fetch_assoc()): ?>
            <tr>
              <td><?= htmlspecialchars($j['mata_kuliah']) ?></td>
              <td><span class="badge bg-primary"><?= $j['kelas'] ?></span></td>
              <td><?= substr($j['jam_mulai'],0,5) ?> - <?= substr($j['jam_selesai'],0,5) ?></td>
            </tr>
          <?php endwhile; else: ?>
            <tr><td colspan="3" class="text-center text-muted">Tidak ada jadwal hari ini</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
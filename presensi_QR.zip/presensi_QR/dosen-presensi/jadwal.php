<?php
$title = 'Jadwal Mengajar';
require_once 'includes/header.php';

// Simpan
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['simpan'])) {
        $stmt = $conn->prepare("INSERT INTO jadwal (mata_kuliah,kelas,hari,jam_mulai,jam_selesai) VALUES (?,?,?,?,?)");
        $stmt->bind_param('sssss', $_POST['mata_kuliah'],$_POST['kelas'],$_POST['hari'],$_POST['jam_mulai'],$_POST['jam_selesai']);
        $stmt->execute();
        redirect('jadwal.php');
    }
    if (isset($_POST['update'])) {
        $stmt = $conn->prepare("UPDATE jadwal SET mata_kuliah=?,kelas=?,hari=?,jam_mulai=?,jam_selesai=? WHERE id=?");
        $stmt->bind_param('sssssi', $_POST['mata_kuliah'],$_POST['kelas'],$_POST['hari'],$_POST['jam_mulai'],$_POST['jam_selesai'],$_POST['id']);
        $stmt->execute();
        redirect('jadwal.php');
    }
}
// Hapus
if (isset($_GET['hapus'])) {
    $conn->query("DELETE FROM jadwal WHERE id=".(int)$_GET['hapus']);
    redirect('jadwal.php');
}

$data = $conn->query("SELECT * FROM jadwal ORDER BY FIELD(hari,'Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu'), jam_mulai");
include 'includes/navbar.php';
?>
<div class="container-fluid py-4 px-4">
  <div class="d-flex justify-content-between mb-3">
    <h4><i class="bi bi-calendar-week"></i> Jadwal Mengajar</h4>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambah">
      <i class="bi bi-plus-circle"></i> Tambah Jadwal
    </button>
  </div>

  <div class="card p-3">
    <div class="table-responsive">
      <table class="table table-hover datatable">
        <thead><tr><th>No</th><th>Mata Kuliah</th><th>Kelas</th><th>Hari</th><th>Jam</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php $i=1; while($r = $data->fetch_assoc()): ?>
            <tr>
              <td><?= $i++ ?></td>
              <td><?= htmlspecialchars($r['mata_kuliah']) ?></td>
              <td><span class="badge bg-primary"><?= $r['kelas'] ?></span></td>
              <td><?= $r['hari'] ?></td>
              <td><?= substr($r['jam_mulai'],0,5) ?> - <?= substr($r['jam_selesai'],0,5) ?></td>
              <td>
                <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#edit<?= $r['id'] ?>"><i class="bi bi-pencil"></i></button>
                <a href="?hapus=<?= $r['id'] ?>" onclick="return confirm('Hapus jadwal?')" class="btn btn-danger btn-sm"><i class="bi bi-trash"></i></a>
              </td>
            </tr>

            <!-- Modal Edit -->
            <div class="modal fade" id="edit<?= $r['id'] ?>">
              <div class="modal-dialog"><form method="post" class="modal-content">
                <div class="modal-header"><h5>Edit Jadwal</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
                <div class="modal-body">
                  <input type="hidden" name="id" value="<?= $r['id'] ?>">
                  <div class="mb-2"><label>Mata Kuliah</label><input name="mata_kuliah" class="form-control" value="<?= htmlspecialchars($r['mata_kuliah']) ?>" required></div>
                  <div class="mb-2"><label>Kelas</label><input name="kelas" class="form-control" value="<?= $r['kelas'] ?>" required></div>
                  <div class="mb-2"><label>Hari</label>
                    <select name="hari" class="form-select" required>
                      <?php foreach(['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu'] as $h): ?>
                        <option <?= $h==$r['hari']?'selected':'' ?>><?= $h ?></option>
                      <?php endforeach; ?>
                    </select>
                  </div>
                  <div class="row">
                    <div class="col mb-2"><label>Jam Mulai</label><input type="time" name="jam_mulai" class="form-control" value="<?= $r['jam_mulai'] ?>" required></div>
                    <div class="col mb-2"><label>Jam Selesai</label><input type="time" name="jam_selesai" class="form-control" value="<?= $r['jam_selesai'] ?>" required></div>
                  </div>
                </div>
                <div class="modal-footer"><button name="update" class="btn btn-primary">Update</button></div>
              </form></div>
            </div>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal Tambah -->
<div class="modal fade" id="modalTambah">
  <div class="modal-dialog"><form method="post" class="modal-content">
    <div class="modal-header"><h5>Tambah Jadwal</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body">
      <div class="mb-2"><label>Mata Kuliah</label><input name="mata_kuliah" class="form-control" required></div>
      <div class="mb-2"><label>Kelas</label><input name="kelas" class="form-control" required></div>
      <div class="mb-2"><label>Hari</label>
        <select name="hari" class="form-select" required>
          <?php foreach(['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu'] as $h): ?>
            <option><?= $h ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="row">
        <div class="col mb-2"><label>Jam Mulai</label><input type="time" name="jam_mulai" class="form-control" required></div>
        <div class="col mb-2"><label>Jam Selesai</label><input type="time" name="jam_selesai" class="form-control" required></div>
      </div>
    </div>
    <div class="modal-footer"><button name="simpan" class="btn btn-primary">Simpan</button></div>
  </form></div>
</div>
<?php include 'includes/footer.php'; ?>
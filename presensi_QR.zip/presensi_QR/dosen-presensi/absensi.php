<?php
$title = 'Absensi';
require_once 'includes/header.php';

// Update status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $stmt = $conn->prepare("UPDATE presensi SET status=? WHERE id=?");
    $stmt->bind_param('si', $_POST['status'], $_POST['id']);
    $stmt->execute();
    redirect('absensi.php?' . $_SERVER['QUERY_STRING']);
}

$tgl = $_GET['tanggal'] ?? date('Y-m-d');
$jadwal_id = (int)($_GET['jadwal'] ?? 0);

$jadwalList = $conn->query("SELECT DISTINCT j.id, j.mata_kuliah, j.kelas FROM jadwal j ORDER BY j.mata_kuliah");

$sql = "SELECT p.*, m.nim, m.nama, m.kelas, j.mata_kuliah 
        FROM presensi p 
        JOIN mahasiswa m ON p.mahasiswa_id=m.id 
        JOIN jadwal j ON p.jadwal_id=j.id 
        WHERE p.tanggal='$tgl'";
if ($jadwal_id) $sql .= " AND p.jadwal_id=$jadwal_id";
$sql .= " ORDER BY p.jam_presensi DESC";
$data = $conn->query($sql);

include 'includes/navbar.php';
?>
<div class="container-fluid py-4 px-4">
  <h4 class="mb-4"><i class="bi bi-check2-square"></i> Absensi Mahasiswa</h4>

  <div class="card p-3 mb-3">
    <form class="row g-2" method="get">
      <div class="col-md-4">
        <label>Tanggal</label>
        <input type="date" name="tanggal" class="form-control" value="<?= $tgl ?>">
      </div>
      <div class="col-md-4">
        <label>Mata Kuliah</label>
        <select name="jadwal" class="form-select">
          <option value="">Semua</option>
          <?php while($j = $jadwalList->fetch_assoc()): ?>
            <option value="<?= $j['id'] ?>" <?= $j['id']==$jadwal_id?'selected':'' ?>>
              <?= htmlspecialchars($j['mata_kuliah']) ?> - <?= $j['kelas'] ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="col-md-4 d-flex align-items-end">
        <button class="btn btn-primary"><i class="bi bi-funnel"></i> Filter</button>
      </div>
    </form>
  </div>

  <div class="card p-3">
    <div class="table-responsive">
      <table class="table table-hover datatable">
        <thead><tr><th>NIM</th><th>Nama</th><th>Kelas</th><th>Matkul</th><th>Jam</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php while($r = $data->fetch_assoc()): ?>
            <tr>
              <td><?= $r['nim'] ?></td>
              <td><?= htmlspecialchars($r['nama']) ?></td>
              <td><?= $r['kelas'] ?></td>
              <td><?= htmlspecialchars($r['mata_kuliah']) ?></td>
              <td><?= substr($r['jam_presensi'],0,5) ?></td>
              <td>
                <?php
                $warna = ['Hadir'=>'success','Izin'=>'warning','Sakit'=>'info','Alpha'=>'danger'];
                ?>
                <span class="badge bg-<?= $warna[$r['status']] ?>"><?= $r['status'] ?></span>
              </td>
              <td>
                <form method="post" class="d-flex gap-1">
                  <input type="hidden" name="id" value="<?= $r['id'] ?>">
                  <select name="status" class="form-select form-select-sm" style="width:auto">
                    <?php foreach(['Hadir','Izin','Sakit','Alpha'] as $s): ?>
                      <option <?= $s==$r['status']?'selected':'' ?>><?= $s ?></option>
                    <?php endforeach; ?>
                  </select>
                  <button name="update_status" class="btn btn-sm btn-primary"><i class="bi bi-check"></i></button>
                </form>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
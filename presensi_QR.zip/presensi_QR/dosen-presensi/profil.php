<?php
$title = 'Profil Dosen';
require_once 'includes/header.php';

$id = $_SESSION['dosen_id'];
$pesan = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profil'])) {
        $nama = $conn->real_escape_string($_POST['nama']);
        $email = $conn->real_escape_string($_POST['email']);
        $foto = $_FILES['foto']['name'] ?? '';
        if ($foto) {
            $ext = pathinfo($foto, PATHINFO_EXTENSION);
            $foto = 'dosen_' . time() . '.' . $ext;
            move_uploaded_file($_FILES['foto']['tmp_name'], 'assets/images/' . $foto);
            $conn->query("UPDATE dosen SET nama='$nama', email='$email', foto='$foto' WHERE id=$id");
        } else {
            $conn->query("UPDATE dosen SET nama='$nama', email='$email' WHERE id=$id");
        }
        $_SESSION['dosen_nama'] = $nama;
        $pesan = 'Profil berhasil diperbarui.';
    }
    if (isset($_POST['ganti_pass'])) {
        $lama = $_POST['lama'];
        $baru = password_hash($_POST['baru'], PASSWORD_DEFAULT);
        $cek = $conn->query("SELECT password FROM dosen WHERE id=$id")->fetch_assoc();
        if (password_verify($lama, $cek['password'])) {
            $conn->query("UPDATE dosen SET password='$baru' WHERE id=$id");
            $pesan = 'Password berhasil diubah.';
        } else {
            $pesan = 'Password lama salah!';
        }
    }
}

$dosen = $conn->query("SELECT * FROM dosen WHERE id=$id")->fetch_assoc();
include 'includes/navbar.php';
?>
<div class="container py-4">
  <h4 class="mb-4"><i class="bi bi-person-circle"></i> Profil Dosen</h4>

  <?php if ($pesan): ?><div class="alert alert-info"><?= $pesan ?></div><?php endif; ?>

  <div class="row g-4">
    <div class="col-md-6">
      <div class="card p-4">
        <h5>Data Profil</h5>
        <form method="post" enctype="multipart/form-data">
          <div class="text-center mb-3">
            <img src="assets/images/<?= $dosen['foto'] ?>" 
                 onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($dosen['nama']) ?>&size=120'"
                 class="rounded-circle" width="120" height="120" style="object-fit:cover">
          </div>
          <div class="mb-3"><label>Nama</label><input name="nama" class="form-control" value="<?= htmlspecialchars($dosen['nama']) ?>" required></div>
          <div class="mb-3"><label>Email</label><input type="email" name="email" class="form-control" value="<?= htmlspecialchars($dosen['email']) ?>" required></div>
          <div class="mb-3"><label>Foto Profil</label><input type="file" name="foto" class="form-control" accept="image/*"></div>
          <button name="update_profil" class="btn btn-primary">Simpan</button>
        </form>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card p-4">
        <h5>Ganti Password</h5>
        <form method="post">
          <div class="mb-3"><label>Password Lama</label><input type="password" name="lama" class="form-control" required></div>
          <div class="mb-3"><label>Password Baru</label><input type="password" name="baru" class="form-control" required></div>
          <button name="ganti_pass" class="btn btn-warning">Ganti Password</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
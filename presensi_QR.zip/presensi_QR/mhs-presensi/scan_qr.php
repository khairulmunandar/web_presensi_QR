<?php
$title = 'Scan Presensi';
require_once 'includes/header.php';
include 'includes/navbar.php';
?>
<div class="container py-4">
  <h4 class="mb-3"><i class="bi bi-qr-code-scan"></i> Scan QR Presensi</h4>

  <div class="card p-4">
    <div id="reader" style="width:100%; max-width:500px; margin:auto;"></div>
    <div id="hasil" class="mt-3"></div>
    <p class="text-muted text-center mt-2">Arahkan kamera ke QR Code yang ditampilkan dosen</p>
  </div>
</div>

<script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
<script>
function onScanSuccess(decodedText) {
    // decodedText bisa berupa URL: https://mhs-presensi.rf.gd/scan_qr.php?token=xxx
    let token = '';
    try {
        const url = new URL(decodedText);
        token = url.searchParams.get('token') || '';
    } catch(e) {
        token = decodedText;
    }

    document.getElementById('hasil').innerHTML = '<div class="alert alert-info">Memproses token: ' + token + '...</div>';
    html5QrcodeScanner.clear();

    fetch('proses_scan.php?token=' + encodeURIComponent(token))
      .then(r => r.json())
      .then(res => {
        const cls = res.success ? 'success' : 'danger';
        document.getElementById('hasil').innerHTML = '<div class="alert alert-' + cls + '">' + res.message + '</div>';
        if (res.success) setTimeout(() => location.href='riwayat.php', 2000);
      })
      .catch(err => {
        document.getElementById('hasil').innerHTML = '<div class="alert alert-danger">Gagal: ' + err + '</div>';
      });
}

const html5QrcodeScanner = new Html5QrcodeScanner("reader", { fps: 10, qrbox: 250 });
html5QrcodeScanner.render(onScanSuccess);
</script>
<?php include 'includes/footer.php'; ?>
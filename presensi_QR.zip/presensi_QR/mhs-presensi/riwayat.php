<?php
$title = 'Riwayat Presensi';
require_once 'includes/header.php';
include 'includes/navbar.php';

$id = $_SESSION['mhs_id'];
$data = $conn->query("SELECT p.*, j.mata_kuliah, j.kelas 
                     FROM presensi p JOIN jadwal j ON p.jadwal_id=j.id 
                     WHERE p.mahasiswa_id=$id 
                     ORDER BY p.tanggal DESC, p.jam_presensi DESC");
?>
<div class="container py-4">
  <h4 class="mb-3"><i class="bi bi-clock-history"></i> Riwayat Presensi</h4>
  <div class="card p-3">
    <div class="table-responsive">
      <table class="table table-hover datatable">
        <thead><tr><th>Tanggal</th><th>Matkul</th><th>Kelas</th><th>Jam</th><th>Status</th></tr></thead>
        <tbody>
          <?php while($r = $data->fetch_assoc()): 
            $warna = ['Hadir'=>'success','Izin'=>'warning','Sakit'=>'info','Alpha'=>'danger']; ?>
            <tr>
              <td><?= $r['tanggal'] ?></td>
              <td><?= htmlspecialchars($r['mata_kuliah']) ?></td>
              <td><?= $r['kelas'] ?></td>
              <td><?= substr($r['jam_presensi'],0,5) ?></td>
              <td><span class="badge bg-<?= $warna[$r['status']] ?>"><?= $r['status'] ?></span></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
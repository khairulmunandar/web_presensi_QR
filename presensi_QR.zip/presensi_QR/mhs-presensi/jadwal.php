<?php
$title = 'Jadwal Kuliah';
require_once 'includes/header.php';
include 'includes/navbar.php';

$kelas = $_SESSION['mhs_kelas'];
$data = $conn->query("SELECT * FROM jadwal WHERE kelas='$kelas' 
                     ORDER BY FIELD(hari,'Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu'), jam_mulai");
?>
<div class="container py-4">
  <h4 class="mb-3"><i class="bi bi-calendar-week"></i> Jadwal Kuliah (<?= $kelas ?>)</h4>
  <div class="card p-3">
    <div class="table-responsive">
      <table class="table table-hover datatable">
        <thead><tr><th>Hari</th><th>Matkul</th><th>Jam</th></tr></thead>
        <tbody>
          <?php while($r = $data->fetch_assoc()): ?>
            <tr>
              <td><?= $r['hari'] ?></td>
              <td><?= htmlspecialchars($r['mata_kuliah']) ?></td>
              <td><?= substr($r['jam_mulai'],0,5) ?> - <?= substr($r['jam_selesai'],0,5) ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
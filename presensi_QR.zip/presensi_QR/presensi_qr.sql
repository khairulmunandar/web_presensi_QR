-- Buat database: presensi_qr

CREATE TABLE dosen (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    foto VARCHAR(255) DEFAULT 'default.png',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE mahasiswa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nim VARCHAR(20) UNIQUE NOT NULL,
    nama VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    kelas VARCHAR(20) NOT NULL,
    foto VARCHAR(255) DEFAULT 'default.png',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE jadwal (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mata_kuliah VARCHAR(100) NOT NULL,
    kelas VARCHAR(20) NOT NULL,
    hari ENUM('Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu') NOT NULL,
    jam_mulai TIME NOT NULL,
    jam_selesai TIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE qr_session (
    id INT AUTO_INCREMENT PRIMARY KEY,
    jadwal_id INT NOT NULL,
    token VARCHAR(64) UNIQUE NOT NULL,
    tanggal DATE NOT NULL,
    waktu_buka DATETIME NOT NULL,
    waktu_tutup DATETIME NOT NULL,
    status ENUM('aktif','expired') DEFAULT 'aktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (jadwal_id) REFERENCES jadwal(id) ON DELETE CASCADE
);

CREATE TABLE presensi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mahasiswa_id INT NOT NULL,
    jadwal_id INT NOT NULL,
    qr_session_id INT,
    tanggal DATE NOT NULL,
    jam_presensi TIME NOT NULL,
    status ENUM('Hadir','Izin','Sakit','Alpha') DEFAULT 'Hadir',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_presensi (mahasiswa_id, jadwal_id, tanggal),
    FOREIGN KEY (mahasiswa_id) REFERENCES mahasiswa(id) ON DELETE CASCADE,
    FOREIGN KEY (jadwal_id) REFERENCES jadwal(id) ON DELETE CASCADE
);

-- Akun dosen default (password: admin123)
INSERT INTO dosen (nama, email, password) VALUES 
('Dosen Pengampu', 'dosen@kampus.ac.id', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1HlWL5uV8Z5cJz5Y5Y5Y5Y5Y5Y5Y5Y5Y');

-- Sample mahasiswa (password: mhs123)
INSERT INTO mahasiswa (nim, nama, email, password, kelas) VALUES 
('2021001', 'Ahmad Fauzi', 'ahmad@mhs.ac.id', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1HlWL5uV8Z5cJz5Y5Y5Y5Y5Y5Y5Y5Y5Y', 'TI-3A'),
('2021002', 'Siti Aminah', 'siti@mhs.ac.id', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1HlWL5uV8Z5cJz5Y5Y5Y5Y5Y5Y5Y5Y5Y', 'TI-3A');

-- Sample jadwal
INSERT INTO jadwal (mata_kuliah, kelas, hari, jam_mulai, jam_selesai) VALUES 
('Rekayasa Perangkat Lunak', 'TI-3A', 'Senin', '08:00:00', '10:30:00'),
('Pemrograman Web', 'TI-3A', 'Rabu', '10:30:00', '13:00:00');
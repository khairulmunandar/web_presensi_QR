<?php
require_once __DIR__ . '/config/database.php';
cekLogin();
$autoload = __DIR__ . '/vendor/autoload.php';
if (!is_file($autoload)) {
  die('Dompdf belum terpasang. Jalankan composer install di folder dosen-presensi.');
}
require $autoload;

use Dompdf\Dompdf;
use Dompdf\Options;

$dari = $_GET['dari'] ?? date('Y-m-01');
$sampai = $_GET['sampai'] ?? date('Y-m-d');
$matkul = $_GET['matkul'] ?? '';
$kelas = $_GET['kelas'] ?? '';

$where = "WHERE p.tanggal BETWEEN '$dari' AND '$sampai'";
if ($matkul) $where .= " AND j.mata_kuliah='".$conn->real_escape_string($matkul)."'";
if ($kelas)  $where .= " AND j.kelas='".$conn->real_escape_string($kelas)."'";

$sql = "SELECT p.*, m.nim, m.nama, j.mata_kuliah, j.kelas 
        FROM presensi p 
        JOIN mahasiswa m ON p.mahasiswa_id=m.id 
        JOIN jadwal j ON p.jadwal_id=j.id 
        $where ORDER BY p.tanggal, p.jam_presensi";
$data = $conn->query($sql);
    $dosenResult = $conn->query("SELECT nama FROM dosen LIMIT 1");
    if (!$data || !$dosenResult) {
      die('Gagal mengambil data laporan.');
    }
    $dosen = $dosenResult->fetch_assoc() ?: ['nama' => ''];

$html = '<style>
body { font-family: Arial, sans-serif; font-size: 11px; }
h2, h3 { text-align: center; margin: 2px; }
table { width: 100%; border-collapse: collapse; margin-top: 10px; }
th, td { border: 1px solid #333; padding: 5px; }
th { background: #DBEAFE; }
.ttd { margin-top: 30px; float: right; text-align: center; width: 200px; }
.logo { width: 70px; }
</style>';

$html .= '<table style="border:none"><tr>
<td style="border:none; width:80px; text-align:center">
<img src="assets/images/logo.png" class="logo" onerror="this.style.display=\'none\'">
</td>
<td style="border:none; text-align:center">
<h2>UNIVERSITAS NAMA KAMPUS</h2>
<h3>LAPORAN PRESENSI MAHASISWA</h3>
<p>Periode: '.$dari.' s/d '.$sampai.'</p>
</td></tr></table><hr>';

$html .= '<table>
<tr><th>No</th><th>NIM</th><th>Nama</th><th>Mata Kuliah</th><th>Kelas</th><th>Tanggal</th><th>Jam</th><th>Status</th></tr>';

$no = 1;
while($r = $data->fetch_assoc()) {
    $html .= '<tr>
      <td>'.$no++.'</td>
      <td>'.$r['nim'].'</td>
      <td>'.htmlspecialchars($r['nama']).'</td>
      <td>'.htmlspecialchars($r['mata_kuliah']).'</td>
      <td>'.$r['kelas'].'</td>
      <td>'.$r['tanggal'].'</td>
      <td>'.substr($r['jam_presensi'],0,5).'</td>
      <td>'.$r['status'].'</td>
    </tr>';
}
$html .= '</table>';

$html .= '<div class="ttd">
<p>Dicetak: '.date('d-m-Y H:i').'</p>
<p>Dosen Pengampu,</p>
<br><br><br>
<p><strong>'.$dosen['nama'].'</strong></p>
</div>';

$options = new Options();
$options->set('isRemoteEnabled', true);
$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'landscape');
$dompdf->render();
$dompdf->stream('Laporan_Presensi_'.$dari.'.pdf', ['Attachment' => false]);
exit;
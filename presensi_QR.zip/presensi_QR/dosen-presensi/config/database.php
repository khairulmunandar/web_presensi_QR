<?php
session_start();

$host = 'localhost';
$user = 'root';        // sesuaikan dengan hosting
$pass = '';            // sesuaikan dengan hosting
$db   = 'presensi_qr';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

date_default_timezone_set('Asia/Jakarta');

// Helper
function cekLogin() {
    if (!isset($_SESSION['dosen_id'])) {
        header('Location: login.php');
        exit;
    }
}

function redirect($url) {
    header("Location: $url");
    exit;
}
?>
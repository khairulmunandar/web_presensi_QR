<?php
require_once 'config/database.php';
cekLogin();
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;

$dari = $_GET['dari'] ?? date('Y-m-01');
$sampai = $_GET['sampai'] ?? date('Y-m-d');
$matkul = $_GET['matkul'] ?? '';
$kelas = $_GET['kelas'] ?? '';

$where = "WHERE p.tanggal BETWEEN '$dari' AND '$sampai'";
if ($matkul) $where .= " AND j.mata_kuliah='".$conn->real_escape_string($matkul)."'";
if ($kelas)  $where .= " AND j.kelas='".$conn->real_escape_string($kelas)."'";

$sql = "SELECT p.*, m.nim, m.nama, j.mata_kuliah, j.kelas 
        FROM presensi p 
        JOIN mahasiswa m ON p.mahasiswa_id=m.id 
        JOIN jadwal j ON p.jadwal_id=j.id 
        $where ORDER BY p.tanggal, p.jam_presensi";
$data = $conn->query($sql);

$dosen = $conn->query("SELECT nama FROM dosen LIMIT 1")->fetch_assoc();

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Laporan Presensi');

// Header
$sheet->mergeCells('A1:G1')->setCellValue('A1', 'UNIVERSITAS NAMA KAMPUS');
$sheet->mergeCells('A2:G2')->setCellValue('A2', 'LAPORAN PRESENSI MAHASISWA');
$sheet->mergeCells('A3:G3')->setCellValue('A3', 'Periode: ' . $dari . ' s/d ' . $sampai);
$sheet->getStyle('A1:G3')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
$sheet->getStyle('A1')->getFont()->setBold(true)->setSize(14);
$sheet->getStyle('A2')->getFont()->setBold(true)->setSize(12);

// Header tabel
$sheet->setCellValue('A5', 'No');
$sheet->setCellValue('B5', 'NIM');
$sheet->setCellValue('C5', 'Nama Mahasiswa');
$sheet->setCellValue('D5', 'Mata Kuliah');
$sheet->setCellValue('E5', 'Kelas');
$sheet->setCellValue('F5', 'Tanggal');
$sheet->setCellValue('G5', 'Status');
$sheet->getStyle('A5:G5')->getFont()->setBold(true);
$sheet->getStyle('A5:G5')->getFill()->setFillType('solid')->getStartColor()->setRGB('DBEAFE');

$row = 6; $no = 1;
while($r = $data->fetch_assoc()) {
    $sheet->setCellValue('A'.$row, $no++);
    $sheet->setCellValue('B'.$row, $r['nim']);
    $sheet->setCellValue('C'.$row, $r['nama']);
    $sheet->setCellValue('D'.$row, $r['mata_kuliah']);
    $sheet->setCellValue('E'.$row, $r['kelas']);
    $sheet->setCellValue('F'.$row, $r['tanggal']);
    $sheet->setCellValue('G'.$row, $r['status']);
    $row++;
}

$sheet->getStyle("A5:G".($row-1))->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
foreach (range('A','G') as $col) $sheet->getColumnDimension($col)->setAutoSize(true);

// Tanda tangan
$row += 2;
$sheet->setCellValue('F'.$row, 'Dicetak: ' . date('d-m-Y H:i'));
$sheet->setCellValue('F'.($row+1), 'Dosen Pengampu,');
$sheet->setCellValue('F'.($row+4), $dosen['nama']);

$filename = 'Laporan_Presensi_' . $dari . '_sd_' . $sampai . '.xlsx';
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="'.$filename.'"');
header('Cache-Control: max-age=0');
$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
<?php
require_once 'config/database.php';

if (isset($_SESSION['dosen_id'])) redirect('dashboard.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $pass  = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM dosen WHERE email = ?");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $dosen = $stmt->get_result()->fetch_assoc();

    if ($dosen && password_verify($pass, $dosen['password'])) {
        $_SESSION['dosen_id']   = $dosen['id'];
        $_SESSION['dosen_nama'] = $dosen['nama'];
        $_SESSION['dosen_foto'] = $dosen['foto'];
        redirect('dashboard.php');
    } else {
        $error = 'Email atau password salah!';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login Dosen</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<style>
body { background: linear-gradient(135deg,#1e3a8a,#3b82f6); min-height:100vh; display:flex; align-items:center; }
.card-login { border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,.2); }
</style>
</head>
<body>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-5">
      <div class="card card-login">
        <div class="card-body p-4">
          <div class="text-center mb-4">
            <i class="bi bi-qr-code-scan text-primary" style="font-size:3rem"></i>
            <h4 class="mt-2">Login Dosen</h4>
            <small class="text-muted">Sistem Presensi QR Code</small>
          </div>
          <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
          <?php endif; ?>
          <form method="post">
            <div class="mb-3">
              <label class="form-label">Email</label>
              <input type="email" name="email" class="form-control" required>
            </div>
            <div class="mb-3">
              <label class="form-label">Password</label>
              <input type="password" name="password" class="form-control" required>
            </div>
            <button class="btn btn-primary w-100">Login</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>
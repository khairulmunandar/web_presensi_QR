<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold" href="dashboard.php">
      <i class="bi bi-qr-code-scan"></i> Presensi Dosen
    </a>
    <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="jadwal.php"><i class="bi bi-calendar-week"></i> Jadwal</a></li>
        <li class="nav-item"><a class="nav-link" href="mahasiswa.php"><i class="bi bi-people"></i> Mahasiswa</a></li>
        <li class="nav-item"><a class="nav-link" href="generate_qr.php"><i class="bi bi-qr-code"></i> Generate QR</a></li>
        <li class="nav-item"><a class="nav-link" href="absensi.php"><i class="bi bi-check2-square"></i> Absensi</a></li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="bi bi-file-earmark-text"></i> Laporan</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="laporan.php?jenis=harian">Laporan Harian</a></li>
            <li><a class="dropdown-item" href="laporan.php?jenis=matkul">Per Mata Kuliah</a></li>
            <li><a class="dropdown-item" href="laporan.php?jenis=kelas">Per Kelas</a></li>
            <li><a class="dropdown-item" href="laporan.php?jenis=rekap">Rekap Kehadiran</a></li>
          </ul>
        </li>
      </ul>
      <ul class="navbar-nav">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
            <i class="bi bi-person-circle"></i> <?= $_SESSION['dosen_nama'] ?>
          </a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="profil.php">Profil</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
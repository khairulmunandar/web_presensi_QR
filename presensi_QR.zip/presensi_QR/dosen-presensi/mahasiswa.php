<?php
$title = 'Data Mahasiswa';
require_once 'includes/header.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama'] ?? '');
    $nim = trim($_POST['nim'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $kelas = trim($_POST['kelas'] ?? '');
    $password = $_POST['password'] ?? '';
    $id = (int)($_POST['id'] ?? 0);

    if ($nama === '' || $nim === '' || $email === '' || $kelas === '') {
        $error = 'Nama, NIM, email, dan kelas wajib diisi.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid.';
    } elseif ($id > 0) {
        if ($password !== '') {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare('UPDATE mahasiswa SET nama=?, nim=?, email=?, kelas=?, password=? WHERE id=?');
            $stmt->bind_param('sssssi', $nama, $nim, $email, $kelas, $hash, $id);
        } else {
            $stmt = $conn->prepare('UPDATE mahasiswa SET nama=?, nim=?, email=?, kelas=? WHERE id=?');
            $stmt->bind_param('ssssi', $nama, $nim, $email, $kelas, $id);
        }
        if ($stmt->execute()) {
            redirect('mahasiswa.php');
        }
        $error = $conn->errno === 1062 ? 'NIM atau email sudah digunakan.' : 'Gagal memperbarui data mahasiswa.';
    } elseif ($password === '') {
        $error = 'Password wajib diisi untuk mahasiswa baru.';
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare('INSERT INTO mahasiswa (nim, nama, email, password, kelas) VALUES (?, ?, ?, ?, ?)');
        $stmt->bind_param('sssss', $nim, $nama, $email, $hash, $kelas);
        if ($stmt->execute()) {
            redirect('mahasiswa.php');
        }
        $error = $conn->errno === 1062 ? 'NIM atau email sudah digunakan.' : 'Gagal menambahkan mahasiswa.';
    }
}

if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    $stmt = $conn->prepare('DELETE FROM mahasiswa WHERE id=?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    redirect('mahasiswa.php');
}

$data = $conn->query('SELECT id, nim, nama, email, kelas FROM mahasiswa ORDER BY kelas, nama');
include 'includes/navbar.php';
?>
<div class="container-fluid py-4 px-4">
  <div class="d-flex justify-content-between mb-3">
    <h4><i class="bi bi-people"></i> Data Mahasiswa</h4>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambah">
      <i class="bi bi-plus-circle"></i> Tambah Mahasiswa
    </button>
  </div>

  <?php if ($error): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <div class="card p-3">
    <div class="table-responsive">
      <table class="table table-hover datatable">
        <thead><tr><th>No</th><th>NIM</th><th>Nama</th><th>Email</th><th>Kelas</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php $i = 1; while ($r = $data->fetch_assoc()): ?>
            <tr>
              <td><?= $i++ ?></td>
              <td><?= htmlspecialchars($r['nim']) ?></td>
              <td><?= htmlspecialchars($r['nama']) ?></td>
              <td><?= htmlspecialchars($r['email']) ?></td>
              <td><span class="badge bg-primary"><?= htmlspecialchars($r['kelas']) ?></span></td>
              <td>
                <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#edit<?= $r['id'] ?>"><i class="bi bi-pencil"></i></button>
                <a href="?hapus=<?= $r['id'] ?>" onclick="return confirm('Hapus mahasiswa ini?')" class="btn btn-danger btn-sm"><i class="bi bi-trash"></i></a>
              </td>
            </tr>
            <div class="modal fade" id="edit<?= $r['id'] ?>">
              <div class="modal-dialog"><form method="post" class="modal-content">
                <div class="modal-header"><h5>Edit Mahasiswa</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
                <div class="modal-body">
                  <input type="hidden" name="id" value="<?= $r['id'] ?>">
                  <div class="mb-2"><label>Nama</label><input name="nama" class="form-control" value="<?= htmlspecialchars($r['nama']) ?>" required></div>
                  <div class="mb-2"><label>NIM</label><input name="nim" class="form-control" value="<?= htmlspecialchars($r['nim']) ?>" required></div>
                  <div class="mb-2"><label>Email</label><input type="email" name="email" class="form-control" value="<?= htmlspecialchars($r['email']) ?>" required></div>
                  <div class="mb-2"><label>Kelas</label><input name="kelas" class="form-control" value="<?= htmlspecialchars($r['kelas']) ?>" required></div>
                  <div class="mb-2"><label>Password Baru <small class="text-muted">(kosongkan jika tidak diubah)</small></label><input type="password" name="password" class="form-control"></div>
                </div>
                <div class="modal-footer"><button name="simpan" class="btn btn-primary">Simpan</button></div>
              </form></div>
            </div>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="modal fade" id="modalTambah">
  <div class="modal-dialog"><form method="post" class="modal-content">
    <div class="modal-header"><h5>Tambah Mahasiswa</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body">
      <div class="mb-2"><label>Nama</label><input name="nama" class="form-control" required></div>
      <div class="mb-2"><label>NIM</label><input name="nim" class="form-control" required></div>
      <div class="mb-2"><label>Email</label><input type="email" name="email" class="form-control" required></div>
      <div class="mb-2"><label>Kelas</label><input name="kelas" class="form-control" required></div>
      <div class="mb-2"><label>Password</label><input type="password" name="password" class="form-control" required></div>
    </div>
    <div class="modal-footer"><button name="simpan" class="btn btn-primary">Simpan</button></div>
  </form></div>
</div>
<?php include 'includes/footer.php'; ?>